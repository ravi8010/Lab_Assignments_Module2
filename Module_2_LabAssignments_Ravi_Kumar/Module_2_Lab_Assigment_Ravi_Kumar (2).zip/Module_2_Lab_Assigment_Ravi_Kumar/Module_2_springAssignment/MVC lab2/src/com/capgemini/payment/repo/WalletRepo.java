package com.capgemini.payment.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.payment.beans.Customer;

public interface WalletRepo extends JpaRepository<Customer, String> {
		
}
