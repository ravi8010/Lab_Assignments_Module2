package com.capgemini;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

@Entity
public class AuthorA {

	@Id
	@GeneratedValue
	private int id;
	private String name;
	@OneToMany(targetEntity=BookA.class)
	private List<BookA> list;
	
	public List<BookA> getList() {
		return list;
	}
	public void setList(List<BookA> list) {
		this.list = list;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
